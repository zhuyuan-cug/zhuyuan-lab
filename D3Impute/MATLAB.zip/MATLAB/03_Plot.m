Y1 = tsne(dropout);  
Y2 = tsne(D3Impute);
Y3 = tsne(scAMF);
Y4 = tsne(DrImpute);  
Y5 = tsne(scImpute);  
Y6 = tsne(scRMD);
Y7 = tsne(SDImpute);  
Y8 = tsne(MAGIC);
Y9 = tsne(GEImpute);
Y10 = tsne(scRNMF);
Y11 = tsne(CMFImpute);
Y12 = tsne(ALRA);
Y13 = tsne(AGImpute);
Y14 = tsne(TsImpute);

figure('Color', 'w');

% Times New Roman
set(groot, 'DefaultAxesFontName', 'Times New Roman');
set(groot, 'DefaultTextFontName', 'Times New Roman');

spacingX = 0.00001;
spacingY = 0.00001;


titles = ["Raw", "D3Impute", "scAMF", "DrImpute", "scImpute", "scRMD", "SDImpute", "MAGIC", "GEImpute", "scRNMF", "CMFImpute", "ALRA", "AGImpute", "TsImpute"];
data = {Y1, Y2, Y3, Y4, Y5, Y6, Y7, Y8, Y9, Y10, Y11, Y12, Y13, Y14};

colors = [230 091 066; 242 143 101; 255 233 173; 149 170 187; 072 116 179]/255 ; % Siletti,petropoulos 
%colors = [230 091 066; 149 170 187]/255 ; % Guo2 
%colors = [230 091 066; 242 143 101; 255 233 173; 149 170 187; 072 116 179; 240 231 252; 234 197 080; 172 206 156; 8 146 146]/255; % Pollen
%colors = [230 091 066; 8 146 146; 255 233 173; 072 116 179]/255 % IPSC
%colors = [230 091 066; 255 233 173; 149 170 187; 072 116 179; 234 197 080; 172 206 156; 8 146 146]/255; % Celltype
%colors = [230 091 066; 8 146 146;  072 116 179]/255 % simulated

for i = 1:14
    subplot(3, 5, i);  

    gscatter(data{i}(:,1), data{i}(:,2), lab, colors); 

    title(titles{i}, 'FontSize', 18, 'FontWeight','bold'); 


    legend('off'); 

    pos = get(gca, 'Position');
    pos(3) = pos(3) - spacingX;
    pos(4) = pos(4) - spacingY; 
    set(gca, 'Position', pos);

    set(gca, 'FontSize', 14, 'FontWeight','bold'); 
end

function [best_fit, best_ari, best_nmi] = EL(data, n_class, lab)

    spectral_fit = spectralcluster(data, n_class);
    
 
    kmeans_fit = kmeans(data, n_class);
    

    ari_spectral = calARI(spectral_fit, lab);
    ari_kmeans = calARI(kmeans_fit, lab); 
    
    nmi_spectral = calMI(spectral_fit, lab);
    nmi_kmeans = calMI(kmeans_fit, lab);


    [best_ari, best_index] = max([ari_spectral, ari_kmeans]);

    methods = ["SpectralCluster",  "Kmeans"];
    switch best_index
        case 1
            best_fit = spectral_fit;
            best_nmi = nmi_spectral;
        case 2
            best_fit = kmeans_fit;
            best_nmi = nmi_kmeans;
    end
    
    fprintf('Optimal clustering method: %s\n', methods(best_index));
    fprintf('Best ARI: %f\n', best_ari);
    fprintf('Best NMI: %f\n', best_nmi);
end


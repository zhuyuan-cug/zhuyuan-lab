function Mout = KNN(sample, knn)
   
    Mout  = sample;  
  
    N = size(sample,1); 
   
    
    D = cosine_dist(sample); 

    knn3 = 10 * knn; 

    [~, Nb_dist] = mink(D, knn3);  

    n = size(D, 1); 

    DI = zeros(n); 

    for ii = 1:n  
      
        for jj = Nb_dist(:,ii)' 
           
            DI(ii,jj) = length(intersect(Nb_dist(1:knn,ii), Nb_dist(1:knn,jj))); 
            
        end
    end

    DI = (knn - max(DI, DI')) / knn; 

    D = DI;  

    [~, Nb_dist] = mink(D, knn); 

    sample_ = single(sample); 

    parfor ii = 1:N 
       
        BNbr = sample_(Nb_dist(:,ii),:); 
    
        xbar = mean(BNbr, 1); 

        Mout(ii,:) = xbar; 
      
    end
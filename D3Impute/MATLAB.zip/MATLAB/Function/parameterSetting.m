function [results] = parameterSetting(data, n_class, lab)
    
    spectral_fit = spectralcluster(data, n_class);
    kmeans_fit = kmeans(data, n_class);

    ari_spectral = calARI(spectral_fit, lab);
    ari_kmeans = calARI(kmeans_fit, lab); 
    
    si_spectral = computeSI(spectral_fit, lab);
    si_kmeans = computeSI(kmeans_fit, lab);

    nmi_spectral = calMI(spectral_fit, lab);
    nmi_kmeans = calMI(kmeans_fit, lab);

    
    fprintf('--- Spectral Clustering ---\n');
    fprintf('ARI: %f\n', ari_spectral);
    fprintf('NMI: %f\n', nmi_spectral);
    fprintf('SI: %f\n\n', si_spectral);

    fprintf('--- K-means Clustering ---\n');
    fprintf('ARI: %f\n', ari_kmeans);
    fprintf('NMI: %f\n', nmi_kmeans);
    fprintf('SI: %f\n\n', si_kmeans);

  
    results = struct();
    results.Spectral = struct('fit', spectral_fit, 'ARI', ari_spectral, 'NMI', nmi_spectral, 'SC', si_spectral);
    results.Kmeans = struct('fit', kmeans_fit, 'ARI', ari_kmeans, 'NMI', nmi_kmeans, 'SC', si_kmeans);
end

function [U,V]=GRNMF(indicate0, cor1, cor2, params)

k=params.k;
I0=indicate0; 
S1_graph_mat = Graph( cor1 , k );
S2_graph_mat = Graph( cor2 , k ); 
R_g = cor2.* S2_graph_mat ;  
R_c = cor1.* S1_graph_mat ;
clear k;

p=params.p;
iterate=params.iterate; 
beta=params.beta;   
lamda_c=params.lamda_c;
lamda_g=params.lamda_g; 
beta > 0 && lamda_c >0 && lamda_g >0;
fprintf('p=%d  maxiter=%d  beta=%d  lamda_c=%d lamda_g=%d\n', p, iterate, beta, lamda_c, lamda_g); 

[rows,cols] = size(I0);
U=abs(rand(p,rows));        
V=abs(rand(p,cols));

D_c = diag(sum(R_c,2));
D_g = diag(sum(R_g,2));
L_c=D_c-R_c;
L_g=D_g-R_g;


fid = fopen( 'RunResult.txt','wt+');
for step=1:iterate
        U1=U.*((V*I0'+lamda_c*U*R_c)./(V*V'*U+lamda_c*U*D_c+beta*U));
        V1=V.*((U1*I0+lamda_g*V*R_g)./(U1*U1'*V+lamda_g*V*D_g+beta*V));
         
        ULU = sum(diag((U1*L_c)*U1'));
        VLV = sum(diag((V1*L_g)*V1'));
        obj = sum(sum((I0-U1'*V1).^2))+beta*(sum(sum(U1.^2)) )+beta*(sum(sum(V1.^2)))+lamda_c*ULU+lamda_g*VLV; 
        
        error=max([max(sum((U1-U).^2)),max(sum((V1-V).^2))]);      
        
        fprintf(fid,'%s\n',[sprintf('step = \t'),int2str(step),...
            sprintf('\t obj = \t'),num2str(obj),...
		    sprintf('\t error = \t'), num2str(error)]);
        fprintf('step=%d  obj=%d  error=%d\n',step, obj, error);   
        if error< 10^(-4)
            fprintf('step=%d\n',step);
            break;
        end
        
        U=U1; 
        V=V1;
        
end
fclose(fid);

end

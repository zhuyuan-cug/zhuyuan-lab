function [ graph ] = Graph( network , k )

tic    
[rows, cols] = size( network );   
        
    %------------------k nearest neighbors--------------%
    
    network= network-diag(diag(network)); 
    kNN = sparse(rows, cols); %zero改为sparse
    graph = sparse(rows, cols);
    [sort_network,idx]=sort(network,2,'descend');
    for i = 1 : rows
        kNN(i,idx(i,1:k))=sort_network(i,1:k);
    end    
    parfor i = 1 : rows
        idx_i = find(kNN(i,:));
        temp_row = zeros(1, cols);
        for j = 1 : rows
            idx_j = find(kNN(j,:));
            if ismember(j,idx_i) && ismember(i,idx_j)
                temp_row(j) = 1;
            elseif ~ismember(j,idx_i) && ~ismember(i,idx_j)
                temp_row(j) = 0;
            else
                temp_row(j) = 0.5;
            end
        end
        graph(i,:) = temp_row;
    end
 toc

end

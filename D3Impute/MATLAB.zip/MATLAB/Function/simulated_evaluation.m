function [pcc, rmse] = simulated_evaluation(raw, random_mask, Impute, transform_method)
    % Parameter description:
    % raw              —— Original expression matrix
    % random_mask      —— Mask matrix with the same dimensions as raw; 0 indicates dropout regions
    % Impute           —— Imputation function handle, e.g., @(x) your_impute_method(x)
    % transform_method —— Data transformation method, e.g., 'log10' or 'none'

    % Generate mask
    mask = (random_mask == 0);

    % Data transformation
    switch transform_method
        case 'log10'
            raw = transform(raw, 'log10');
        case 'log1p'
            raw = log1p(raw);
        case 'none'
            % No transformation
        otherwise
            error('Unknown data transformation method: %s', transform_method);
    end

    % Retrieve ground truth and imputed values
    true_vals = raw(mask);
    imputed_vals = Impute(mask);

    % Pearson correlation coefficient
    pcc = corr(true_vals, imputed_vals);

    % Root mean square error
    rmse = sqrt(mean((true_vals - imputed_vals).^2));

    % Output results
    fprintf('PCC in imputed region: %.4f\n', pcc);
    fprintf('RMSE in imputed region: %.4f\n', rmse);
end

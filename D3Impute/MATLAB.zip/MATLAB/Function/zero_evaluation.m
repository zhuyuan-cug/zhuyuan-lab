function [tech_fill_ratio, bio_misfill_ratio] = zero_evaluation(raw, dropout, imputed)
    % Technical zero mask: original data is non-zero but masked as 0
    tech_mask = (raw ~= 0) & (dropout == 0);

    % Biological zero mask: original data is 0 and masked as 0
    bio_mask = (raw == 0) & (dropout == 0);

    % Total count statistics
    total_tech = sum(tech_mask(:));
    total_bio = sum(bio_mask(:));

    % Number of filled technical zeros
    tech_filled = sum(imputed(tech_mask) ~= 0);

    % Number of misfilled biological zeros
    bio_misfilled = sum(imputed(bio_mask) ~= 0);

    % Ratio calculation
    tech_fill_ratio = tech_filled / total_tech;
    bio_misfill_ratio = bio_misfilled / total_bio;

    % Output results
    fprintf('Technical zero fill ratio: %.4f\n', tech_fill_ratio);
    fprintf('Biological zero misfill ratio: %.4f\n', bio_misfill_ratio);
end

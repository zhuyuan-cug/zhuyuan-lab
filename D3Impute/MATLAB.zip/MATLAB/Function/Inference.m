function [impute, indicate0, indicate1]= Inference(dropout, bulk, out, options)
% dropout: cell*gene
% bulk: gene*sample

%% prepare data
indicate0 = dropout;
indicate0(indicate0 > 0) = 1;
cor1 = corr(dropout');
cor2 = corr(bulk');

min_val1 = min(cor1(:), [], 'omitnan');
min_val2 = min(cor2(:), [], 'omitnan');

cor1(isnan(cor1)) = min_val1;
cor2(isnan(cor2)) = min_val2;

[U, V] = GRNMF(indicate0, cor1, cor2, options); 
inference = U' * V;

indicate1 = inference;
indicate1(indicate1 > 0.1) = 1;
indicate1(indicate1 <= 0.1) = 0;

%% impute
[m, n] = size(dropout);
impute = zeros(m, n);
parfor i = 1:m
    for j = 1:n
        if (dropout(i, j) == 0  && indicate1(i, j) == 1)
            impute(i, j) = out(i, j);
        elseif(dropout(i, j) > 0)
            impute(i, j) = dropout(i, j);
        end
    end
end

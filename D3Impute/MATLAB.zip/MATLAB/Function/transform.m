function Matrix_T = transform(Matrix,type)

switch type
    case 'value2trans'
        [~, sortedIndices] = sort(Matrix, 2);

        OrdinalNumbers = repmat(1:size(Matrix, 2), size(Matrix, 1), 1);

        linearIndex = sub2ind(size(Matrix), repmat((1:size(Matrix, 1))', 1, size(Matrix, 2)), sortedIndices);

        Matrix_T = zeros(size(Matrix)); Matrix_T(linearIndex) = (OrdinalNumbers/size(Matrix, 2)).^0.5;

    case 'unitvector'
        Matrix_T = Matrix./sqrt(sum(Matrix.^2,2));

    case 'log'
        Matrix_T = log2(Matrix + 1);
    
    case 'log10'
         Matrix_T = log10(Matrix + 1);

    case 'loge'
         Matrix_T = log(Matrix + 1);
    
    case 'Freeman'
        X_normalized = (Matrix - min(Matrix(:))) / (max(Matrix(:)) - min(Matrix(:))); 
        Matrix_T = sqrt(X_normalized) + sqrt(X_normalized + 1);  

    case 'boxcox'
        min_value = min(Matrix(:));
        if min_value <= 0
            shift_value = abs(min_value) + 1;
            data_shifted = Matrix + shift_value;
        else
            data_shifted = Matrix;
        end

        Matrix_T = zeros(size(data_shifted));
        lambda_values = zeros(1, size(data_shifted, 2));
        for col = 1:size(data_shifted, 2)
            column_data = data_shifted(:, col);
            
            if any(column_data <= 0)
                error('All data must be positive for the Box-Cox transformation to work.');
            end
            

            [Matrix_T(:, col), lambda_values(col)] = boxcox(column_data);
        end

end

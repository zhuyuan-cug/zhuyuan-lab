clc;
clear;

%% Add Path 
addpath('C:/hsy/D3Impute/Function');
addpath('C:/hsy/D3Impute/Tool');

%% Data Import
% scRNA-seq matrix : cell*gene
dropout = csvread('C:/hsy/D3Impute/data/Siletti/sc.csv', 1, 1);
dropout = dropout';

% lab 
[m, n] = size(dropout);
lab = readmatrix('C:/hsy/D3Impute/data/Siletti/cell_types.csv');
lab = lab(:, 2);

%% Data Tranform
fea_raw = full(dropout);
fea_bx = transform(fea_raw,'boxcox');



label_1_numr = lab;
label_1_numr = label_1_numr + 1;
n_class = length(unique(label_1_numr));

%% Prepare Impute
out = manfit_cosine(fea_bx, 23);

[a, ARI, NMI] = EL(out, n_class,lab);
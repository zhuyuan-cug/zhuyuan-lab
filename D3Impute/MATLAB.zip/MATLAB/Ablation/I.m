clc;
clear;

%% Add Path 
addpath('C:/hsy/D3Impute/Function');
addpath('C:/hsy/D3Impute/Tool');

%% Data Import
% scRNA-seq matrix : cell*gene
dropout = csvread('C:/hsy/D3Impute/Siletti/sc.csv', 1, 1);
dropout = dropout';

[m, n] = size(dropout);
lab = readmatrix('C:/hsy/D3Impute/Siletti/cell_types.csv');
lab = lab(:, 2);

%% Data
fea_raw = full(dropout);

label_1_numr = lab;
label_1_numr = label_1_numr + 1;
n_class = length(unique(label_1_numr));

%% Prepare Impute
out = manfit_cosine(fea_raw,23);

[a, ARI, NMI] = EL(out, n_class,lab);

%% initialize counters
count_00 = 0;
count_01 = 0;
count_10 = 0;
count_11 = 0;

%% zero porportion 
total_elements = numel(indicate1);  
zero_elements = sum(indicate1(:) == 0); 
zero_proportion = zero_elements / total_elements; 

%% Loop through each element and count occurrences
for i = 1:numel(indicate1)
    if indicate1(i) == 0 && indicate(i) == 0
        count_00 = count_00 + 1;

    elseif indicate1(i) == 0 && indicate(i) == 1
        count_01 = count_01 + 1;
       
    elseif indicate1(i) == 1 && indicate(i) == 0
        count_10 = count_10 + 1;
       
    elseif indicate1(i) == 1 && indicate(i) == 1
        count_11 = count_11 + 1;
    end
end

count_00 = count_00 / total_elements;
count_01 = count_01 / total_elements;
count_10 = count_10 / total_elements;
count_11 = count_11 / total_elements;


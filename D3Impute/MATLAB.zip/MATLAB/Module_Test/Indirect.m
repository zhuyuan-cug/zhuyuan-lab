clc;
clear;


addpath(genpath('.\Tool'));
addpath(genpath('.\Function'));

%% data import
dropout = csvread('C:/hsy/data/Celltype/sc.csv', 1, 1);
dropout = dropout'

bulk = csvread('C:/hsy/data/Celltype/bulk.csv', 1, 1);

[m, n] = size(dropout);
lab = readmatrix('C:/hsy/data/Celltype/cell_types.csv');
lab = lab(: , 2);


SDImpute= csvread('C:/hsy/data/Celltype/SDImpute.csv', 1, 1)
SDImpute = SDImpute'
scImpute = csvread('C:/hsy/data/Celltype/scImpute.csv', 1, 1)
scImpute = scImpute'
DrImpute= csvread('C:/hsy/data/Celltype/DrImpute.csv', 1, 1)
DrImpute = DrImpute'
CMFImpute= csvread('C:/hsy/data/Celltype/CMFImpute.csv', 1, 1)
CMFImpute = CMFImpute'
ALRA= csvread('C:/hsy/data/Celltype/ALRA.csv', 1, 1)
ALRA = ALRA'
AGImpute= csvread('C:/hsy/data/Celltype/AGImpute.csv', 1, 1)
AGImpute = AGImpute'
TsImpute= csvread('C:/hsy/data/Celltype/TsImpute.csv', 1, 1)
ALRA = TsImpute'

indicate1 = dropout;
indicate1(indicate1 > 0) = 1;

indicate = scImpute;
indicate(indicate > 0) = 1;

indicate = SDImpute;
indicate (indicate >0) = 1;

indicate = ALRA;
indicate (indicate >0) = 1;

indicate = DrImpute;
indicate (indicate >0) = 1;

indicate = CMFImpute;
indicate (indicate >0) = 1;

indicate = AGImpute;
indicate (indicate >0) = 1;

indicate = TsImpute;
indicate (indicate >0) = 1;

fea_raw = full(dropout);
fea_bx = transform(fea_raw,'boxcox');

label_1_numr = lab;
label_1_numr = label_1_numr + 1;
n_class = length(unique(label_1_numr));
ppx = min(50,length(label_1_numr)-1);


out = KNN(fea_bx,23); % Mean smoothing
out1 = manfit_cosine(fea_bx,23); % Heterogeneity-aware

%% impute
impute = zeros(m, n); % Mean smoothing
for i = 1:m
    for j = 1:n
        if (dropout(i, j) == 0  && indicate(i, j) == 1)
            impute(i, j) = out(i, j);
        elseif(dropout(i, j) > 0)
            impute(i, j) = dropout(i, j);
        end
    end
end

impute1 = zeros(m, n); % Heterogeneity-aware
for i = 1:m
    for j = 1:n
        if (dropout(i, j) == 0  && indicate(i, j) == 1)
            impute1(i, j) = out1(i, j);
        elseif(dropout(i, j) > 0)
            impute1(i, j) = dropout(i, j);
        end
    end
end


%% clustering
n_class = length(unique(lab));
[our, ARI, NMI] = EL(impute, n_class,lab); % Mean smoothing
[our1, ARI1, NMI1] = EL(impute1, n_class,lab); % Heterogeneity-aware


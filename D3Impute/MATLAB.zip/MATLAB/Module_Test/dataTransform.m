clc;
clear;

%% data import
dropout = csvread('C:/hsy/D3Impute/data/Siletti/sc.csv', 1, 1);
dropout = dropout';

[m, n] = size(dropout);
lab = readmatrix('C:/hsy/D3Impute/data/Siletti/cell_types.csv');
lab = lab(: , 2);

sc_vtr = csvread('C:/hsy/D3Impute/data/Siletti/dataTransform/sc-vtr.csv', 1, 1);
sc_cosine = csvread('C:/hsy/D3Impute/data/Siletti/dataTransform/sc-cosine.csv', 1, 1);
sc_ln = csvread('C:/hsy/D3Impute/data/Siletti/dataTransform/sc-ln.csv', 1, 1);
sc_log2 = csvread('C:/hsy/D3Impute/data/Siletti/dataTransform/sc-log2.csv', 1, 1);
sc_log10 = csvread('C:/hsy/D3Impute/data/Siletti/dataTransform/sc-log10.csv', 1, 1);
sc_loge = csvread('C:/hsy/D3Impute/data/Siletti/dataTransform/sc-loge.csv', 1, 1);
sc_boxcox = csvread('C:/hsy/D3Impute/data/Siletti/dataTransform/sc-boxcox.csv', 1, 1);
sc_freeman = csvread('C:/hsy/D3Impute/data/Siletti/dataTransform/sc-freeman.csv', 1, 1);

sc_vtr = sc_vtr';
sc_cosine = sc_cosine';
sc_ln = sc_ln';
sc_log2 = sc_log2';
sc_log10= sc_log10';
sc_loge = sc_loge';
sc_boxcox = sc_boxcox';
sc_freeman = sc_freeman';


n_class = length(unique(lab));

fit =  kmeans(dropout, n_class);
a1 = computeSI(dropout, fit);

fit1 = kmeans(sc_vtr, n_class);
a2 = computeSI(sc_vtr, fit1);

fit2 = kmeans(sc_cosine, n_class);
a3 = computeSI(sc_cosine, fit2);

fit3 = kmeans(sc_ln, n_class);
a4 = computeSI(sc_ln, fit3);

fit4 = kmeans(sc_log2, n_class);
a5 = computeSI(sc_log2, fit4);

fit5 = kmeans(sc_log10, n_class);
a6 = computeSI(sc_log10, fit5);

fit6 = kmeans(sc_loge, n_class);
a7 = computeSI(sc_loge, fit6);

fit7 = kmeans(sc_boxcox, n_class);
a8 = computeSI(sc_boxcox, fit7);

fit8 = kmeans(sc_freeman, n_class);
a9 = computeSI(sc_freeman, fit8);


% ch1 = evalclusters(dropout, fit, 'CalinskiHarabasz');
% ch2 = evalclusters(sc_vtr, fit1, 'CalinskiHarabasz');
% ch3 = evalclusters(sc_cosine, fit2, 'CalinskiHarabasz');
% ch4 = evalclusters(sc_ln, fit3, 'CalinskiHarabasz');
% ch5 = evalclusters(sc_log2, fit4, 'CalinskiHarabasz');
% ch6 = evalclusters(sc_log10, fit5, 'CalinskiHarabasz');
% ch7 = evalclusters(sc_loge, fit6, 'CalinskiHarabasz');
% ch8 = evalclusters(sc_boxcox, fit7, 'CalinskiHarabasz');
% ch9 = evalclusters(sc_freeman, fit8, 'CalinskiHarabasz');
% 
% ch1 = ch1.CriterionValues;
% ch2 = ch2.CriterionValues;
% ch3 = ch3.CriterionValues;
% ch4 = ch4.CriterionValues;
% ch5 = ch5.CriterionValues;
% ch6 = ch6.CriterionValues;
% ch7 = ch7.CriterionValues;
% ch8 = ch8.CriterionValues;
% ch9 = ch9.CriterionValues;
% 
% 
% db1 = evalclusters(dropout, fit, 'DaviesBouldin');
% db2 = evalclusters(sc_vtr, fit1, 'DaviesBouldin');
% db3 = evalclusters(sc_cosine, fit2, 'DaviesBouldin');
% db4 = evalclusters(sc_ln, fit3, 'DaviesBouldin');
% db5 = evalclusters(sc_log2, fit4, 'DaviesBouldin');
% db6 = evalclusters(sc_log10, fit5, 'DaviesBouldin');
% db7 = evalclusters(sc_loge, fit6, 'DaviesBouldin');
% db8 = evalclusters(sc_boxcox, fit7, 'DaviesBouldin');
% db9 = evalclusters(sc_freeman, fit8, 'DaviesBouldin');
% 
% db1 = db1.CriterionValues;
% db2 = db2.CriterionValues;
% db3 = db3.CriterionValues;
% db4 = db4.CriterionValues;
% db5 = db5.CriterionValues;
% db6 = db6.CriterionValues;
% db7 = db7.CriterionValues;
% db8 = db8.CriterionValues;
% db9 = db9.CriterionValues;
% 

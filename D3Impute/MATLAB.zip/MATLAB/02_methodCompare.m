clc;
clear;

addpath('C:/hsy/D3Impute/Function');
addpath('C:/hsy/D3Impute/Tool');

%% data import
dropout = csvread('C:/hsy/D3Impute/data/Siletti/sc.csv', 1, 1);
dropout = dropout'

bulk = csvread('C:/hsy/D3Impute/data/Siletti/bulk.csv', 1, 1);

[m, n] = size(dropout);
lab = readmatrix('C:/hsy/D3Impute/data/Siletti/cell_types.csv');
lab = lab(: , 2);

D3Impute= csvread('C:/hsy/D3Impute/data/Siletti/D3Impute.csv', 1, 1)
D3Impute = D3Impute'
SDImpute= csvread('C:/hsy/D3Impute/data/Siletti/SDImpute.csv', 1, 1)
SDImpute = SDImpute'
MAGIC= csvread('C:/hsy/D3Impute/data/Siletti/MAGIC.csv', 1, 1)
MAGIC = MAGIC'
CMFImpute= csvread('C:/hsy/D3Impute/data/Siletti/CMFImpute.csv', 1, 1)
CMFImpute = CMFImpute'
scRMD = csvread('C:/hsy/D3Impute/data/Siletti/scRMD.csv', 1, 1)
scRMD = scRMD'
scRNMF= csvread('C:/hsy/D3Impute/data/Siletti/scRNMF.csv', 1, 1)
scRNMF = scRNMF'
DrImpute = csvread('C:/hsy/D3Impute/data/Siletti/DrImpute.csv', 1, 1)
DrImpute = DrImpute'
scImpute = csvread('C:/hsy/D3Impute/data/Siletti/scImpute.csv', 1, 1)
scImpute = scImpute'
GEImpute= csvread('C:/hsy/D3Impute/data/Siletti/GEImpute.csv', 1, 1)
GEImpute = GEImpute'
ALRA= csvread('C:/hsy/D3Impute/data/Siletti/ALRA.csv', 1, 1)
ALRA = ALRA'
scAMF = csvread('C:/hsy/D3Impute/data/Siletti/scAMF.csv', 1, 1);
scAMF = scAMF';
AGImpute= csvread('C:/hsy/D3Impute/data/Siletti/AGImpute.csv', 1, 1);
AGImpute = AGImpute';
TsImpute= csvread('C:/hsy/D3Impute/data/Siletti/TsImpute.csv', 1, 1);
TsImpute = TsImpute';

n_class = length(unique(lab));
[a, ARI1, NMI1] = EL(dropout, n_class,lab);
[b, ARI2, NMI2] = EL(D3Impute, n_class,lab);
[c, ARI3, NMI3] = EL(scAMF, n_class,lab);
[d, ARI4, NMI4] = EL(DrImpute, n_class,lab);
[e, ARI5, NMI5] = EL(scImpute, n_class,lab);
[f, ARI6, NMI6] = EL(scRMD, n_class,lab);
[g, ARI7, NMI7] = EL(SDImpute, n_class,lab);
[h, ARI8, NMI8] = EL(MAGIC, n_class,lab);
[i, ARI9, NMI9] = EL(GEImpute, n_class,lab);
[j, ARI10, NMI10] = EL(scRNMF, n_class,lab);
[k, ARI11, NMI11] = EL(CMFImpute, n_class,lab);
[m, ARI12, NMI12] = EL(ALRA, n_class,lab);
[l, ARI13, NMI13] = EL(AGImpute, n_class,lab);
[n, ARI14, NMI14] = EL(TsImpute, n_class,lab);
clc;
clear;

%% Memory and time start records
% Wall-clock time start
start_time = datetime('now');

% Memory and time start records
if ispc
    [user, ~] = memory;
    mem_before = user.MemUsedMATLAB;
else
    mem_before = NaN;
    warning(['The memory function is only available on Windows platforms. ' ...
        'Skipping memory recording.']);
end

tic;

%% Add Path 
addpath('C:/hsy/D3Impute/Function');
addpath('C:/hsy/D3Impute/Tool');

%% Data Import
% scRNA-seq matrix : cell*gene
dropout = csvread('C:/hsy/D3Impute/data/Siletti/sc.csv', 1, 1);
dropout = dropout';

% bulk matrix : gene*sample
bulk = csvread('C:/hsy/D3Impute/data/Siletti/bulk.csv', 1, 1);

% lab 
[m, n] = size(dropout);
lab = readmatrix('C:/hsy/D3Impute/data/Siletti/cell_types.csv');
lab = lab(:, 2);

%% Data Tranform
fea_raw = full(dropout);
bulk_raw = full(bulk);
fea_bx = transform(fea_raw,'boxcox');
bulk_bx = transform(bulk_raw, ['boxcox']);


label_1_numr = lab;
label_1_numr = label_1_numr + 1;
n_class = length(unique(label_1_numr));

%% Prepare Impute
out = manfit_cosine(fea_bx, 23);  % neigborhood size

%% setting inference
options = struct;
options.k = 23;  % neigborhood size
options.p = 10; % subsapce dimensionality
options.iterate = 100;
options.beta = 0.001; % sparseness constraint coefficient
options.lamda_c = 0.1; % cell graph regularization coefficient
options.lamda_g = 0.1; % gene graph regularization coefficient

[impute, indicate0, indicate1] = Inference(fea_bx, bulk_bx, out, options);

%% Memory and Time End Records
time_elapsed = toc;
end_time = datetime('now');
actual_duration = end_time - start_time;

if ispc
    [user, ~] = memory;
    mem_after = user.MemUsedMATLAB;
    mem_used_MB = (mem_after - mem_before) / (1024^2);
    fprintf('\nTotal runtime (tic/toc): %.2f seconds\n', time_elapsed);
    fprintf('Wall-clock time elapsed: %s\n', string(actual_duration));
    fprintf('MATLAB memory usage increased: %.2f MB\n', mem_used_MB);
else
    fprintf('\nTotal runtime (tic/toc): %.2f seconds\n', time_elapsed);
    fprintf('Wall-clock time elapsed: %s\n', string(actual_duration));
end


%% save imputed result
[numGenes, numCells] = size(impute');
cellNames = ["", "cell" + string(1:numCells)]; 
geneNames = "gene" + string(1:numGenes)';
imputeWithGeneNames = [geneNames, string(impute')];
csvContent = [cellNames; imputeWithGeneNames];
writematrix(csvContent, 'C:/hsy/D3Impute.csv'); % gene*cell

%% Clustering
[a, ARI, NMI] = EL(impute, n_class,lab);




function  distance = cosine_dist(samples)

num_samples = size(samples, 1);
cosine_similarity_matrix = zeros(num_samples);

for i = 1:num_samples
    for j = 1:num_samples

        vec1 = samples(i, :);
        vec2 = samples(j, :);
        

        dot_product = dot(vec1, vec2);

        norm_vec1 = norm(vec1);
        norm_vec2 = norm(vec2);

        cosine_similarity = dot_product / (norm_vec1 * norm_vec2);
        

        cosine_similarity_matrix(i, j) = cosine_similarity;
    end
end

A = ones(size(cosine_similarity_matrix))
distance  =  A-cosine_similarity_matrix
distance = abs(distance)



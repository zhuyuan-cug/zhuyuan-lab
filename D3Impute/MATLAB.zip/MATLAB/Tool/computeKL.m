function kl_divergence = computeKL(dropout, transform);
dropout_c = sum(dropout);
transform_c = nansum(transform);

disp(dropout_c);
disp(transform_c);


epsilon = 1e-10;
dropout_c(dropout_c == 0) = epsilon;
transform_c(transform_c == 0) = epsilon;

dropout_c = dropout_c / sum(dropout_c);
transform_c = transform_c / sum(transform_c);


kl_divergence = sum(dropout_c .* log(dropout_c ./ transform_c));

disp('KL :');
disp(kl_divergence);

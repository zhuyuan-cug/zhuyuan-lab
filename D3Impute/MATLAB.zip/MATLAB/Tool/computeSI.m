function si = computeSI(data, labels)

    silhouette_vals = silhouette(data, labels);
    

    si = mean(silhouette_vals);
end

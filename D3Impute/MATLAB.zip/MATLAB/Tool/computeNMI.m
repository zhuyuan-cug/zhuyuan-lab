function nmi = computeNMI(labels_true, labels_pred)

    conf_matrix = confusionmat(labels_true, labels_pred);

    num_samples = sum(conf_matrix(:));

    p_true = sum(conf_matrix, 2) / num_samples;
    p_pred = sum(conf_matrix, 1) / num_samples;
    

    joint_prob = conf_matrix / num_samples;

    mutual_info = 0;
    for i = 1:size(joint_prob, 1)
        for j = 1:size(joint_prob, 2)
            if joint_prob(i, j) > 0
                mutual_info = mutual_info + joint_prob(i, j) * log2(joint_prob(i, j) / (p_true(i) * p_pred(j)));
            end
        end
    end

    entropy_true = -sum(p_true .* log2(p_true + eps));
    entropy_pred = -sum(p_pred .* log2(p_pred + eps));
    nmi = mutual_info / sqrt(entropy_true * entropy_pred);
end

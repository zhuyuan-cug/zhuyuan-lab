import numpy as np

def cosine_dist(samples):
    """
    Compute pairwise cosine distance matrix from input samples.

    Parameters:
    -----------
    samples : numpy.ndarray
        A 2D array of shape (n_samples, n_features)

    Returns:
    --------
    distance : numpy.ndarray
        A 2D array of shape (n_samples, n_samples) containing cosine distances
    """
    num_samples = samples.shape[0]
    cosine_similarity_matrix = np.zeros((num_samples, num_samples))

    for i in range(num_samples):
        for j in range(num_samples):
            vec1 = samples[i, :]
            vec2 = samples[j, :]

            dot_product = np.dot(vec1, vec2)
            norm_vec1 = np.linalg.norm(vec1)
            norm_vec2 = np.linalg.norm(vec2)

            if norm_vec1 == 0 or norm_vec2 == 0:
                cosine_similarity = 0.0  # Handle zero vectors safely
            else:
                cosine_similarity = dot_product / (norm_vec1 * norm_vec2)

            cosine_similarity_matrix[i, j] = cosine_similarity

    # Convert similarity to distance
    distance = np.abs(1 - cosine_similarity_matrix)
    return distance

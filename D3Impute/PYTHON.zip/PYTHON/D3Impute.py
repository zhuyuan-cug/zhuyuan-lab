import os
import numpy as np
import pandas as pd
from Function.transform import data_to_tranform, read_numeric_labels
from Function.manifit import manfit_cosine
from Function.Inference import Inference
from Function.EL import EL

# === Path Configuration ===
parentPath = './Siletti/'

# File names
sc = 'sc.csv'               # Single-cell expression matrix (genes × cells)
bulk = 'bulk.csv'           # Bulk expression matrix (genes × samples)
lab = 'cell_types.csv'      # Cell type labels
D3Impute = 'D3Impute.csv' # Output file for imputed single-cell data

# Full file paths
scPath = os.path.join(parentPath, sc)
bulkPath = os.path.join(parentPath, bulk)
labPath = os.path.join(parentPath, lab)
savePath = os.path.join(parentPath, D3Impute)

### Step 1. Load and preprocess data
# Apply Box-Cox transformation to single-cell and bulk data
dropout = data_to_tranform(scPath, data_type='sc', trans_type='boxcox')
bulk = data_to_tranform(bulkPath, data_type='bulk', trans_type='boxcox')

# Read numeric cell type labels
lab = read_numeric_labels(labPath)

# Shift labels to start from 1 (if needed)
lab_1_numr = lab + 1
n_class = len(np.unique(lab_1_numr))  # Number of unique cell types

### Step 2. Manifold learning
# Construct similarity graph using cosine similarity
out = manfit_cosine(dropout, knn=23)

### Step 3. Imputation via graph-regularized NMF
# Define model parameters
options = {
    'k': 23,           # Neighborhood size for graph construction
    'p': 10,           # Subspace dimensionality
    'iterate': 100,    # Maximum number of iterations
    'beta': 0.001,     # Sparsity regularization coefficient
    'lamda_c': 0.1,    # Cell graph regularization coefficient
    'lamda_g': 0.1     # Gene graph regularization coefficient
}

# Run imputation algorithm
impute, I0, I1 = Inference(dropout, bulk, out, options)

### Step 4. Save imputed result to CSV
# Transpose imputed matrix to match gene × cell format
impute_T = impute.T
numGenes, numCells = impute_T.shape

# Generate column and row labels
cell_names = [''] + [f'cell{i+1}' for i in range(numCells)]
gene_names = [f'gene{i+1}' for i in range(numGenes)]

# Create DataFrame and insert gene names as first column
df = pd.DataFrame(impute_T, columns=[f'cell{i+1}' for i in range(numCells)])
df.insert(0, '', gene_names)

# Save to CSV file
df.to_csv(savePath, index=False, header=cell_names)

### Step 5. Evaluate clustering performance
# Run clustering evaluation (Spectral Clustering vs KMeans)
a, ARI, NMI = EL(impute, n_class, lab)

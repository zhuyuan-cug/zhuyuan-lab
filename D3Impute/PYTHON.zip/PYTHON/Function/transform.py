import numpy as np
import pandas as pd
from scipy.stats import boxcox


def transform(matrix, trans_type):
    """
    Transform a matrix using various transformation methods.

    Parameters:
    -----------
    matrix : numpy.ndarray
        Input matrix to be transformed
    trans_type : str
        Type of transformation to apply
        Options: 'unitvector', 'log10', 'boxcox'

    Returns:
    --------
    matrix_t : numpy.ndarray
        Transformed matrix
    """

    if trans_type == 'unitvector':
        # Normalize each row to unit vector
        row_norms = np.sqrt(np.sum(matrix ** 2, axis=1, keepdims=True))
        matrix_t = matrix / row_norms


    elif trans_type == 'log10':
        # Log base 10 transformation
        matrix_t = np.log10(matrix + 1)

    elif trans_type == 'boxcox':
        matrix_t = np.zeros_like(matrix)
        lambda_values = np.zeros(matrix.shape[1])

        for col in range(matrix.shape[1]):
            column_data = matrix[:, col]

            # 如果该列包含非正值，则单独平移
            min_val = np.min(column_data)
            if min_val <= 0:
                shift = abs(min_val) + 1
                column_data = column_data + shift

            # 再次检查是否仍有非正值（理论上不会，但保险起见）
            if np.any(column_data <= 0):
                raise ValueError(f"Column {col} still contains non-positive values after shifting.")

            # 检查是否为常数列
            if np.all(column_data == column_data[0]):
                matrix_t[:, col] = 0  # 或 column_data
                lambda_values[col] = np.nan
                print(f"Column {col} is constant. Skipped Box-Cox.")
                continue

            matrix_t[:, col], lambda_values[col] = boxcox(column_data)

    return matrix_t

def data_to_tranform (csvPath, data_type ,trans_type):
    """
        Load a gene expression CSV file and apply matrix transformation.

        Parameters:
        -----------
        csvPath : str
            Path to the input CSV file. The first column should contain gene names.
            For single-cell data, the first row should contain cell names.

        data_type : str
            Type of input data. Accepts:
            - 'sc'   : single-cell data (genes × cells), will be transposed to cells × genes
            - 'bulk' : bulk RNA-seq data (gene × samples), no transposition needed

        trans_type : str
            Type of transformation to apply. Supported options include:
            - 'log10', 'unitvector', 'boxcox'

        Returns:
        --------
        df_transform : pandas.DataFrame
            Transformed expression matrix with cells as rows and genes as columns.
        """
    df = pd.read_csv(csvPath, index_col=0)

    if data_type == 'sc':
        df_transposed = df.T
        matrix = df_transposed.values.astype(float)
    elif data_type == 'bulk':
        matrix = df.values.astype(float)

    df_transform = transform(matrix, trans_type=trans_type)

    return df_transform


def read_numeric_labels(label_path):
    """
    Read cell type labels from a CSV file and extract numeric labels for clustering ground truth.

    Parameters:
    -----------
    label_path : str
        Path to the label CSV file. The first row should contain column headers like 'CellType', 'label'.
        The first column should contain cell names, and the second column should contain numeric labels.

    Returns:
    --------
    labels : pandas.Series
        A Series of numeric labels indexed by cell name.
    """
    # Read CSV file
    df = pd.read_csv(label_path, index_col=0)

    # Extract numeric labels only
    numeric_labels = pd.to_numeric(df['label'], errors='coerce')

    # Drop any non-numeric or missing labels
    numeric_labels = numeric_labels.dropna().astype(int)

    return numeric_labels
import numpy as np
from sklearn.metrics.pairwise import euclidean_distances
from Tool.cosine_dist import cosine_dist

def manfit_cosine(sample, knn):
    """
    Neighborhood smoothing with cosine-based structure and local optimization.

    Parameters:
    -----------
    sample : numpy.ndarray
        Input matrix of shape (n_samples, n_features)
    knn : int
        Number of neighbors to use

    Returns:
    --------
    Mout : numpy.ndarray
        Smoothed matrix of same shape as input
    """
    Mout = sample.copy()
    N = sample.shape[0]

    # Step 1: Cosine distance
    D = cosine_dist(sample)

    # Step 2: Get 10×knn neighbors
    knn3 = 10 * knn
    Nb_dist = np.argsort(D, axis=1)[:, :knn3]  # shape: (N, knn3)

    # Step 3: Compute DI matrix based on neighbor intersection
    DI = np.zeros_like(D)
    for ii in range(N):
        for jj in Nb_dist[ii]:
            inter = np.intersect1d(Nb_dist[ii, :knn], Nb_dist[jj, :knn])
            DI[ii, jj] = len(inter)

    # Step 4: Normalize DI to get new distance matrix
    DI = (knn - np.maximum(DI, DI.T)) / knn
    D = DI

    # Step 5: Get refined knn neighbors
    Nb_dist = np.argsort(D, axis=1)[:, :knn]

    # Step 6: Local optimization
    sample_ = sample.astype(np.float32)
    weights = np.array([-0.1, -0.05, 0, 0.05, 0.1])

    for ii in range(N):
        neighbors = sample_[Nb_dist[ii], :]  # shape: (knn, features)
        xbar = np.mean(neighbors, axis=0)
        d = xbar - sample_[ii, :]

        x_final = xbar.copy()
        ds_final = np.sum(euclidean_distances([x_final], neighbors)**2)

        for w in weights:
            x_temp = xbar + w * d
            ds = np.sum(euclidean_distances([x_temp], neighbors)**2)
            if ds <= ds_final:
                x_final = x_temp
                ds_final = ds

        Mout[ii, :] = x_final

    return Mout

import numpy as np
from sklearn.cluster import SpectralClustering, KMeans
from sklearn.metrics import adjusted_rand_score, normalized_mutual_info_score

def EL(data, n_class, lab):
    # Spectral Clustering
    spectral = SpectralClustering(
        n_clusters=n_class,
        affinity='rbf',
        assign_labels='kmeans',
        gamma=1.0,
        random_state=42
    )
    spectral_fit = spectral.fit_predict(data)

    # KMeans Clustering
    kmeans = KMeans(n_clusters=n_class, n_init=10, random_state=42)
    kmeans_fit = kmeans.fit_predict(data)

    # ARI and NMI scores
    ari_spectral = adjusted_rand_score(lab, spectral_fit)
    ari_kmeans = adjusted_rand_score(lab, kmeans_fit)

    nmi_spectral = normalized_mutual_info_score(lab, spectral_fit, average_method='max')
    nmi_kmeans = normalized_mutual_info_score(lab, kmeans_fit, average_method='max')

    # Choose best method
    scores = [ari_spectral, ari_kmeans]
    best_index = int(np.argmax(scores))
    best_ari = scores[best_index]

    methods = ["SpectralCluster", "KMeans"]
    if best_index == 0:
        best_fit = spectral_fit
        best_nmi = nmi_spectral
    else:
        best_fit = kmeans_fit
        best_nmi = nmi_kmeans

    print(f"Optimal clustering method: {methods[best_index]}")
    print(f"Best ARI: {best_ari:.6f}")
    print(f"Best NMI: {best_nmi:.6f}")

    return best_fit, best_ari, best_nmi

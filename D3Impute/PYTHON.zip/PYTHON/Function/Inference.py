import numpy as np
from Function.GRNMF import GRNMF

def Inference(dropout, bulk, out, options):
    indicate0 = (dropout > 0).astype(int)

    cor1 = np.corrcoef(dropout)
    cor2 = np.corrcoef(bulk)

    min_val1 = np.nanmin(cor1)
    min_val2 = np.nanmin(cor2)

    cor1 = np.where(np.isnan(cor1), min_val1, cor1)
    cor2 = np.where(np.isnan(cor2), min_val2, cor2)

    U, V = GRNMF(indicate0, cor1, cor2, options)

    inference = U.T @ V

    indicate1 = (inference > 0.1).astype(int)

    impute = np.zeros_like(dropout)

    mask_fill_from_out = (dropout == 0) & (indicate1 == 1)
    mask_keep_dropout = (dropout > 0)

    impute[mask_fill_from_out] = out[mask_fill_from_out]
    impute[mask_keep_dropout] = dropout[mask_keep_dropout]

    return  impute, indicate0, indicate1
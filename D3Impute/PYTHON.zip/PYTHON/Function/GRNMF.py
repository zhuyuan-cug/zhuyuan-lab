import numpy as np
from Function.Graph import build_graph
def GRNMF(indicate0, cor1, cor2, params):
    k = params['k']
    I0 = indicate0
    S1_graph_mat = build_graph(cor1, k)
    S2_graph_mat = build_graph(cor2, k)
    R_g = cor2 * S2_graph_mat
    R_c = cor1 * S1_graph_mat

    p = params['p']
    iterate = params['iterate']
    beta = params['beta']
    lamda_c = params['lamda_c']
    lamda_g = params['lamda_g']

    assert beta > 0 and lamda_c > 0 and lamda_g > 0
    print(f'p={p}  maxiter={iterate}  beta={beta}  lamda_c={lamda_c} lamda_g={lamda_g}')

    rows, cols = I0.shape

    U = np.abs(np.random.rand(p, rows))
    V = np.abs(np.random.rand(p, cols))

    D_c = np.diag(np.sum(R_c, axis=1))
    D_g = np.diag(np.sum(R_g, axis=1))
    L_c = D_c - R_c
    L_g = D_g - R_g

    with open('RunResult.txt', 'w') as fid:
        for step in range(1, iterate + 1):
            numerator_U = V @ I0.T + lamda_c * U @ R_c
            denominator_U = V @ V.T @ U + lamda_c * U @ D_c + beta * U
            U1 = U * (numerator_U / (denominator_U + 1e-10))

            numerator_V = U1 @ I0 + lamda_g * V @ R_g
            denominator_V = U1 @ U1.T @ V + lamda_g * V @ D_g + beta * V
            V1 = V * (numerator_V / (denominator_V + 1e-10))

            ULU = np.sum(np.diag(U1 @ L_c @ U1.T))
            VLV = np.sum(np.diag(V1 @ L_g @ V1.T))
            obj = np.sum((I0 - U1.T @ V1) ** 2) + beta * (np.sum(U1 ** 2) + np.sum(V1 ** 2)) + lamda_c * ULU + lamda_g * VLV

            error = max(np.max(np.sum((U1 - U) ** 2, axis=0)), np.max(np.sum((V1 - V) ** 2, axis=0)))

            fid.write(f'step = \t{step}\t obj = \t{obj}\t error = \t{error}\n')
            print(f'step={step}  obj={obj}  error={error}')
            if error < 1e-4:
                print(f'step={step}')
                break

            U = U1
            V = V1

    return U, V

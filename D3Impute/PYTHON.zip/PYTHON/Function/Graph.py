import numpy as np
from scipy.sparse import lil_matrix

def build_graph(network, k):
    """
    Construct a symmetric k-nearest neighbor graph with mutual neighbor weighting.

    Parameters:
    -----------
    network : numpy.ndarray
        Input similarity matrix (square, symmetric)
    k : int
        Number of neighbors to retain

    Returns:
    --------
    graph : scipy.sparse.lil_matrix
        Symmetric graph with weights: 1 (mutual), 0.5 (one-way), 0 (none)
    """
    rows, cols = network.shape

    # Remove diagonal (self-similarity)
    network = network - np.diag(np.diag(network))

    # Step 1: Build kNN matrix
    kNN = lil_matrix((rows, cols))
    sorted_indices = np.argsort(network, axis=1)[:, ::-1]  # descending
    sorted_values = np.sort(network, axis=1)[:, ::-1]

    for i in range(rows):
        kNN[i, sorted_indices[i, :k]] = sorted_values[i, :k]

    # Step 2: Build symmetric graph with mutual neighbor logic
    graph = lil_matrix((rows, cols))
    for i in range(rows):
        idx_i = kNN.rows[i]
        temp_row = np.zeros(cols)
        for j in range(rows):
            idx_j = kNN.rows[j]
            if j in idx_i and i in idx_j:
                temp_row[j] = 1.0
            elif j not in idx_i and i not in idx_j:
                temp_row[j] = 0.0
            else:
                temp_row[j] = 0.5
        graph[i, :] = temp_row

    return graph
